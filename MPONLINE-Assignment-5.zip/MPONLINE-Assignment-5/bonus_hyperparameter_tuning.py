"""
Bonus Challenge (Not Mandatory - No Extra Marks)
-------------------------------------------------
Hyperparameter tuning experiment: varying `max_depth` of the Decision Tree
Classifier and reporting whether performance improved.

Run:
    python bonus_hyperparameter_tuning.py
"""

import warnings
warnings.filterwarnings("ignore")

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

RANDOM_STATE = 42

# --- Load & preprocess (same steps as Assignment-5.py) ---
df = pd.read_csv("data/WA_Fn-UseC_-HR-Employee-Attrition.csv")
df = df.drop(columns=["EmployeeCount", "StandardHours", "EmployeeNumber", "Over18"])

le = LabelEncoder()
df["Attrition"] = le.fit_transform(df["Attrition"])

cat_cols = df.select_dtypes(include="object").columns.tolist()
df = pd.get_dummies(df, columns=cat_cols, drop_first=True)

X = df.drop(columns=["Attrition"])
y = df["Attrition"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=y
)

# --- Baseline: default Decision Tree (max_depth=None, i.e. fully grown) ---
print(f"{'max_depth':>10} | {'Accuracy':>9} | {'Precision':>9} | {'Recall':>7} | {'F1-Score':>8}")
print("-" * 55)

for depth in [None, 3, 5, 8, 10]:
    model = DecisionTreeClassifier(max_depth=depth, random_state=RANDOM_STATE)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)

    acc = accuracy_score(y_test, preds)
    prec = precision_score(y_test, preds)
    rec = recall_score(y_test, preds)
    f1 = f1_score(y_test, preds)

    label = "None (full)" if depth is None else depth
    print(f"{str(label):>10} | {acc:9.4f} | {prec:9.4f} | {rec:7.4f} | {f1:8.4f}")

print("""
Effect of max_depth:
A fully-grown tree (max_depth=None) has the lowest bias but the highest
variance: it keeps splitting until every leaf is (almost) pure, so it fits
noise in the training set and can perform worse in accuracy on unseen test
data than a shallower tree, even though it may pick up more of the true
minority-class patterns (higher recall/F1 in this run). Restricting
max_depth to a small value (e.g. 3-5) prunes the tree, usually raising test
accuracy but pushing predictions toward the majority class ("No"), which can
lower recall/F1 for the minority ("Yes") class. Somewhere in the middle
(e.g. max_depth=8-10) tends to give the best trade-off between overall
accuracy and the ability to still catch attrition cases.
""")
